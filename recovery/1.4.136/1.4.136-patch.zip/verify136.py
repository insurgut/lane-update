from pathlib import Path
import zipfile,struct,hashlib,zlib,subprocess
with zipfile.ZipFile('base/1.4.131.apk') as old,zipfile.ZipFile('1.4.136.apk') as z:
 assert z.testzip() is None and set(z.namelist())==set(old.namelist())
 replaced={p.name for p in Path('patched136').glob('*')}
 assert replaced=={'AndroidManifest.xml'}|{p.name for p in Path('patched136').glob('*.dex')}
 for n in old.namelist():
  if n not in replaced and not n.startswith('META-INF/'):assert old.read(n)==z.read(n),n
  info=z.getinfo(n)
  if n.endswith('.dex'):
   b=z.read(n);assert b[:4]==b'dex\n' and struct.unpack_from('<I',b,32)[0]==len(b),n
   assert b[12:32]==hashlib.sha1(b[32:]).digest(),n
   assert struct.unpack_from('<I',b,8)[0]==zlib.adler32(b[12:])&0xffffffff,n
   assert struct.unpack_from('<I',b,88)[0]<65536,n
  if info.compress_type==0:
   with open('1.4.136.apk','rb') as f:f.seek(info.header_offset+26);nl,extra=struct.unpack('<HH',f.read(4))
   assert (info.header_offset+30+nl+extra)%(16384 if n.endswith('.so') else 4)==0,n
for main,args in [('Verify136',[]),('AppLinks88',['1.4.136.apk'])]:
 subprocess.run(['java','-Xmx2g','-cp','.:classes136:bootstrap:tools/*',main]+args,check=True)
print('PASS ZIP/DEX checksums, method limits, alignment; resources/unrelated entries unchanged')
print('SHA256',hashlib.sha256(Path('1.4.136.apk').read_bytes()).hexdigest())
