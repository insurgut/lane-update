from pathlib import Path
import zipfile
with zipfile.ZipFile('base/1.4.131.apk') as z:
 for name in ('signing.pk8','signing.der'):
  Path('tools',name).write_bytes(z.read('assets/lane_editor/'+name))
