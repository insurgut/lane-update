from pathlib import Path
import zipfile,copy,struct,io,os
replacements={p.name:p.read_bytes() for p in Path('patched136').glob('*')}
assert {'AndroidManifest.xml','classes7.dex'}.issubset(replacements)
buffer=io.BytesIO()
with zipfile.ZipFile('base/1.4.131.apk') as old,zipfile.ZipFile(buffer,'w') as out:
 for original in old.infolist():
  name=original.filename;upper=name.upper()
  if upper=='META-INF/MANIFEST.MF' or(name.startswith('META-INF/') and '/' not in name[9:] and upper.endswith(('.SF','.RSA','.DSA','.EC'))):continue
  info=copy.copy(original);data=replacements.pop(name,old.read(name));info.extra=b''
  if info.compress_type==zipfile.ZIP_STORED:
   align=16384 if name.endswith('.so') else 4;offset=out.fp.tell()+30+len(name.encode());pad=(-offset)%align
   if pad:
    if pad<4:pad+=align
    info.extra=struct.pack('<HH',0xd938,pad-4)+b'\0'*(pad-4)
  out.writestr(info,data)
 assert not replacements
with open('aligned.apk','wb') as final:
 final.write(buffer.getvalue());final.flush();os.fsync(final.fileno())
print('PASS repack: audited manifest/DEX replacements only; native 16KiB alignment preserved')
