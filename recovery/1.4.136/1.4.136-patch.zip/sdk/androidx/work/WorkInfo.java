package androidx.work;public class WorkInfo {public enum State {a,b,c,d,e,f}}
