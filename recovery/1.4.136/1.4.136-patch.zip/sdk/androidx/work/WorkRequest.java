package androidx.work;public class WorkRequest {public static class Builder {public androidx.work.impl.model.WorkSpec b;}}
