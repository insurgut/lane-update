package androidx.work.impl.model;public class WorkGenerationalId {public WorkGenerationalId(String id,int generation){}}
