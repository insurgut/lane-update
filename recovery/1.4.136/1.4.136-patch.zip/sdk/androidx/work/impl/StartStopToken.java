package androidx.work.impl;public class StartStopToken {public StartStopToken(androidx.work.impl.model.WorkGenerationalId id){}}
