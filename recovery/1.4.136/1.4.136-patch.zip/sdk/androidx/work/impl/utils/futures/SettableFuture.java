package androidx.work.impl.utils.futures;public abstract class SettableFuture<V> implements com.google.common.util.concurrent.ListenableFuture<V>{}
