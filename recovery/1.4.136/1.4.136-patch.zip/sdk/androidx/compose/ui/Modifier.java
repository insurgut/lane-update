package androidx.compose.ui; public interface Modifier {public static final Companion Companion=new Companion(); public static final class Companion implements Modifier {}}
