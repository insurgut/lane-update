package androidx.compose.foundation.layout; public final class SizeKt {public static androidx.compose.ui.Modifier u(androidx.compose.ui.Modifier m,float width){return m;}}
