package kotlinx.coroutines;public final class TimeoutKt{public static Object b(long ms,kotlin.jvm.functions.Function2 f,kotlin.coroutines.Continuation c){return null;}}
