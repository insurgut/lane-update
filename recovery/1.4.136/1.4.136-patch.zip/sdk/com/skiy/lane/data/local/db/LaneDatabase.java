package com.skiy.lane.data.local.db;public abstract class LaneDatabase{public abstract DownloadedTracksDao y();}
