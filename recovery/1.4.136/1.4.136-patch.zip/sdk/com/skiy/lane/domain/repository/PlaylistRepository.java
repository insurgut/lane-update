package com.skiy.lane.domain.repository;public interface PlaylistRepository{Object h(String id,kotlin.coroutines.jvm.internal.ContinuationImpl c);}
