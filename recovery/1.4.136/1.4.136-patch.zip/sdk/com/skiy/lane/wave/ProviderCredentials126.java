package com.skiy.lane.wave; final class ProviderCredentials126 {static String LASTFM="fixture-lastfm",YANDEX="fixture-yandex";}
