from pathlib import Path
import subprocess,zipfile,glob,shutil
run=lambda a:subprocess.run(a,check=True)
run(['python3','bootstrap_signing.py'])
for p in ('classes136','dex136','patched136'):shutil.rmtree(p,ignore_errors=True)
run(['java','-jar','tools/ecj.jar','-nowarn','-1.8','-proc:none','-cp','tools/android.jar:tools/xmlpull.jar:tools/json.jar:tools/guava.jar','-d','classes136']+[str(p) for r in ('src','sdk') for p in Path(r).rglob('*.java')])
Path('dex136').mkdir()
roots=('Logcat131','SessionStore131','DownloadStart130','Prefetch135','CacheDb132','Catalog132','Known134')
with zipfile.ZipFile('helper136.jar','w') as z:
 for p in Path('classes136/com/skiy/lane').rglob('*.class'):
  if p.stem.split('$')[0] in roots:z.write(p,str(p.relative_to('classes136')))
run(['java','-cp','tools/r8.jar','com.android.tools.r8.D8','--lib','tools/android.jar','--min-api','26','--output','dex136','helper136.jar'])
run(['java','-jar','tools/ecj.jar','-nowarn','-17','-proc:none','-cp','.:bootstrap:'+':'.join(glob.glob('tools/*.jar')),'-d','.','Build136.java','Sign136.java'])
run(['java','-cp','.:bootstrap:tools/*','Build136'])
run(['python3','package136.py'])
run(['java','-cp','.:bootstrap:tools/*','Sign136'])
