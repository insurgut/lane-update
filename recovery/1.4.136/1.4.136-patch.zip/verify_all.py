import glob,subprocess
run=lambda a:subprocess.run(a,check=True)
run(['java','-jar','tools/ecj.jar','-nowarn','-17','-proc:none','-cp','.:bootstrap:'+':'.join(glob.glob('tools/*.jar')),'-d','.','Verify136.java','Verify126.java','Build126.java','AppLinks88.java'])
run(['python3','test131.py'])
run(['python3','verify136.py'])
