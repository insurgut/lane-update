package com.skiy.lane.wave;
import java.net.*;import javax.net.ssl.HttpsURLConnection;import java.io.*;import org.json.*;
public final class ProviderHttp126 {
 public static final class Failure extends IOException {public final int status;Failure(int s){super(s==401?"Яндекс Музыка: токен отклонён":s==403?"Яндекс Музыка: доступ запрещён":s==451?"Яндекс Музыка недоступна для текущего подключения (451)":s==429?"Слишком много запросов к музыкальному сервису":"Музыкальный сервис: HTTP "+s);status=s;}}
 static volatile long blockedUntil;
 static String read(String raw,boolean auth,String form)throws Exception {
  if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException();URL u=new URL(raw);if(!u.getProtocol().equals("https")||u.getUserInfo()!=null||u.getPort()!=-1&&u.getPort()!=443)throw new IOException("Требуется защищённый адрес музыкального сервиса");
  if(auth&&!u.getHost().equals("api.music.yandex.net"))throw new IOException("Неверный адрес API");if(!auth&&!ProviderPolicy126.yandexHost(u.getHost())&&!u.getHost().equals("ws.audioscrobbler.com"))throw new IOException("Недопустимый адрес музыкального сервиса");
  if(auth&&System.currentTimeMillis()<blockedUntil)throw new Failure(429);
  HttpsURLConnection c=(HttpsURLConnection)u.openConnection();try{c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","Lane/1.4.126");if(auth)c.setRequestProperty("Authorization","OAuth "+ProviderCredentials126.YANDEX);if(form!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(form.getBytes("UTF-8"));}}
   int status=c.getResponseCode();if(status<200||status>=300){if(auth&&status==429)blockedUntil=System.currentTimeMillis()+60000;throw new Failure(status);}try(InputStream in=c.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();if(bytes.size()+n>4*1024*1024)throw new IOException("Слишком большой ответ музыкального сервиса");bytes.write(b,0,n);}return bytes.toString("UTF-8");}
  }finally{c.disconnect();}
 }
 static Object api(String path,String form)throws Exception{JSONObject d=new JSONObject(read("https://api.music.yandex.net"+path,true,form));if(d.has("error"))throw new IOException("Яндекс Музыка отклонила запрос");if(!d.has("result"))throw new IOException("Некорректный ответ Яндекс Музыки");return d.get("result");}
 static String encode(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
}
