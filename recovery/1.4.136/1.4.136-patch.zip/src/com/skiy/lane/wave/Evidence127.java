package com.skiy.lane.wave;
import java.util.*;import java.lang.ref.WeakReference;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
/** Metadata preparation stays off the UI thread; bonus only reads published scores. */
public final class Evidence127 {
 static final Map<String,Map<String,Double>> graph=new LinkedHashMap<String,Map<String,Double>>();
 static final AtomicBoolean building=new AtomicBoolean();static final AtomicLong revision=new AtomicLong();
 static final ScheduledThreadPoolExecutor worker=new ScheduledThreadPoolExecutor(1,new ThreadFactory(){public Thread newThread(Runnable r){Thread t=new Thread(r,"LaneWaveEvidence128");t.setDaemon(true);t.setPriority(Thread.NORM_PRIORITY-1);return t;}});
 static volatile Snapshot snapshot;static volatile long requestedAt;static long lastUpdate;static boolean queued;
 static String key(String a,String t){return ProviderPolicy126.norm(a)+"|"+ProviderPolicy126.norm(t);}
 static String key(WaveModel.Item i){return key(i.artist,i.title);}
 static synchronized boolean record(String seed,String service,Map<String,Double> values){Map<String,Double> clean=new LinkedHashMap<String,Double>();for(Map.Entry<String,Double> e:values.entrySet()){double v=Taste127.finite(e.getValue());if(v>=.15&&!e.getKey().equals(seed))clean.put(e.getKey(),Math.min(1,v));if(clean.size()>=40)break;}String k=service+":"+seed;if(clean.equals(graph.get(k)))return false;if(graph.size()>=256&&!graph.containsKey(k))graph.remove(graph.keySet().iterator().next());graph.put(k,Collections.unmodifiableMap(clean));return true;}
 static synchronized double value(String service,String seed,String candidate){Map<String,Double> map=graph.get(service+":"+seed);Double v=map==null?null:map.get(candidate);return v==null?0:v;}
 static final class Raw {final String id,artist,title,genre;final double strength;Raw(WaveModel.Item i,double strength){id=i.id;artist=i.artist;title=i.title;genre=i.genre;this.strength=strength;}}
 static final class Seed {final String id,artist,title,key;final Set<String> genres;Seed(Raw r){id=r.id;artist=r.artist;title=r.title;key=key(artist,title);genres=Taste127.genres(r.genre);}}
 static final class Row {final String artist,title,genre;final double[] signals;Row(Raw r,double[] s){artist=r.artist;title=r.title;genre=r.genre;signals=s;}}
 static final class Snapshot {final WeakReference<WaveModel> model;final String account;final long generation,time;final int count;final Seed[] seeds;final Map<String,Row> rows;Snapshot(WaveModel m,String a,long g,long t,int c,Seed[] s,Map<String,Row> r){model=new WeakReference<WaveModel>(m);account=a;generation=g;time=t;count=c;seeds=s;rows=Collections.unmodifiableMap(r);}}
 // Called on the background worker. Copy only scalars under the existing model lock.
 static List<Raw> capture(WaveModel model,long now){List<Raw> all=new ArrayList<Raw>(model.items.size());for(WaveModel.Item i:model.items.values())all.add(new Raw(i,Taste127.strength(model,i,now)));return all;}
 static Snapshot prepare(WaveModel model,String account,long generation,long now,List<Raw> all){
  List<Raw> positive=new ArrayList<Raw>();for(Raw r:all)if(r.strength>0)positive.add(r);
  Collections.sort(positive,new Comparator<Raw>(){public int compare(Raw a,Raw b){return Double.compare(b.strength,a.strength);}});
  Set<String> artists=new HashSet<String>();List<Seed> seeds=new ArrayList<Seed>();for(int i=0;i<positive.size()&&i<32&&seeds.size()<6;i++){Raw r=positive.get(i);String a=ProviderPolicy126.norm(r.artist);if(!a.isEmpty()&&artists.add(a))seeds.add(new Seed(r));}
  Seed[] selected=seeds.toArray(new Seed[seeds.size()]);Map<String,Map<String,Double>> links; synchronized(Evidence127.class){links=new HashMap<String,Map<String,Double>>(graph);}
  Map<String,Set<String>> genreCache=new HashMap<String,Set<String>>();Map<String,Row> rows=new HashMap<String,Row>();for(Raw r:all){if(Thread.currentThread().isInterrupted())break;String target=key(r.artist,r.title);Set<String> genres=genreCache.get(r.genre);if(genres==null){genres=Taste127.genres(r.genre);if(genreCache.size()<256)genreCache.put(r.genre,genres);}double[] signals=new double[selected.length*2];boolean any=false;
   for(int i=0;i<selected.length;i++){Seed seed=selected[i];if(seed.key.equals(target))continue;Map<String,Double> lf=links.get("lf:"+seed.key),ym=links.get("ym:"+seed.key);Double lv=lf==null?null:lf.get(target),yv=ym==null?null:ym.get(target);double a=lv==null?0:lv,b=yv==null?0:yv;signals[2*i]=.35*Math.max(a,b)+.20*Math.min(a,b);for(String g:seed.genres)if(genres.contains(g)){signals[2*i+1]=.2;break;}if(signals[2*i]>0||signals[2*i+1]>0)any=true;
   }if(any)rows.put(r.id,new Row(r,signals));
  }return new Snapshot(model,account,generation,now,all.size(),selected,rows);
 }
 /** Hot path: no parsing, regex, I/O, allocation, or shared monitor acquisition. */
 public static double bonus(WaveModel model,WaveModel.Item target,long now,List<WaveModel.Item> ignored){
  if(!Taste127.allowed(model,target,now))return 0;Snapshot s=snapshot;
  if(s==null||s.model.get()!=model||s.generation!=Wave.generation||!Objects.equals(s.account,Wave.account)){request();return 0;}
  if(s.count!=model.items.size()||now-s.time>60000)request();Row row=s.rows.get(target.id);if(row==null||!Objects.equals(row.artist,target.artist)||!Objects.equals(row.title,target.title)||!Objects.equals(row.genre,target.genre))return 0;
  double best=0,genre=0;for(int i=0;i<s.seeds.length;i++){Seed seed=s.seeds[i];WaveModel.Item current=model.items.get(seed.id);if(current==null||!Objects.equals(current.artist,seed.artist)||!Objects.equals(current.title,seed.title))continue;double weight=Taste127.strength(model,current,now)/5;if(weight<=0)continue;best=Math.max(best,weight*row.signals[2*i]);genre=Math.max(genre,weight*row.signals[2*i+1]);}return Math.min(.75,best+genre);
 }
 static void request(){if(Wave.app==null)return;long now=System.currentTimeMillis();if(now-requestedAt<1000||!building.compareAndSet(false,true))return;requestedAt=now;final long start=revision.get();worker.schedule(new Runnable(){public void run(){try{WaveModel m;String account;long generation;long time=System.currentTimeMillis();List<Raw> all;synchronized(Wave.lock){m=Wave.model;account=Wave.account;generation=Wave.generation;all=capture(m,time);}Snapshot ready=prepare(m,account,generation,time,all);if(ProviderWave126.current(generation,account)&&Wave.model==m){snapshot=ready;notifyReady(generation,account);}}finally{building.set(false);if(revision.get()!=start)requestedAt=0;if(revision.get()!=start)request();}}},50,TimeUnit.MILLISECONDS);}
 static void changed(){revision.incrementAndGet();request();}
 static void notifyReady(final long generation,final String account){if(Wave.main==null)return;synchronized(Evidence127.class){if(queued)return;queued=true;}long delay=Math.max(1000,60000-(System.currentTimeMillis()-lastUpdate));Wave.main.postDelayed(new Runnable(){public void run(){synchronized(Evidence127.class){queued=false;}if(ProviderWave126.current(generation,account)&&Wave.active){lastUpdate=System.currentTimeMillis();Wave.rebuild();}}},delay);}
}
