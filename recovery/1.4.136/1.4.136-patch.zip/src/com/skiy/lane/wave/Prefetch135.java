package com.skiy.lane.wave;
import android.util.Log;import java.util.*;import kotlin.coroutines.*;import kotlin.coroutines.jvm.internal.ContinuationImpl;import kotlin.jvm.functions.Function2;import kotlinx.coroutines.TimeoutKt;import com.skiy.lane.domain.repository.PlaylistRepository;
/** Bounds only the optional playlist-wide URL optimization. Original worker fallback is unchanged. */
public final class Prefetch135 {
 static volatile String last="Подготовка ещё не запускалась";
 public static Object read(Object repository,String id,Object continuation){last="Запрос ссылок плейлиста "+id+" (предел 5 с)";Log.i("LaneDownloads",last);return TimeoutKt.b(5000,new Block((PlaylistRepository)repository,id),new Report((Continuation)continuation));}
 static final class Block implements Function2{final PlaylistRepository repository;final String id;Block(PlaylistRepository r,String i){repository=r;id=i;}public Object invoke(Object scope,Object continuation){return repository.h(id,new Bridge((Continuation)continuation));}}
 static final class Bridge extends ContinuationImpl{Bridge(Continuation c){super(c);}public Object invokeSuspend(Object result){return result;}}
 static final class Report extends ContinuationImpl{Report(Continuation c){super(c);}public Object invokeSuspend(Object result){last=result instanceof Map?"Общий запрос завершён, ссылок: "+((Map)result).size():"Общий запрос завершён или прерван; используется обработка каждого трека";Log.i("LaneDownloads",last);return result;}}
 public static void stage(Object task){try{java.lang.reflect.Field f=task.getClass().getDeclaredField("n");f.setAccessible(true);last="Подготовка плейлиста, состояние: "+f.getInt(task);Log.i("LaneDownloads",last);}catch(Exception e){Log.w("LaneDownloads","Cannot read playlist producer stage",e);}}
 public static void submitted(String name){last="Передача задания "+name+" в WorkManager";Log.i("LaneDownloads",last);}
}
