package com.skiy.lane.wave;
import android.content.Context;import android.graphics.*;import android.view.View;import java.io.*;
import androidx.compose.runtime.Composer;import androidx.compose.ui.Modifier;import androidx.compose.foundation.layout.RowScopeInstance;import androidx.compose.foundation.layout.SizeKt;import androidx.compose.ui.viewinterop.AndroidView_androidKt;import kotlin.jvm.functions.Function1;import kotlin.Unit;import com.skiy.lane.apkeditor.Palette;
/** Replaces only HomeTopBar's logo slot; avatar/notification Compose nodes stay native. */
public final class Header129 {
 private static Bitmap artwork;
 private static final Function1<Context,View> FACTORY=new Function1<Context,View>(){public View invoke(Context context){return new LogoView(context);}};
 public static Modifier edgeSpacer(Modifier modifier,float oldWidth){return SizeKt.u(modifier,0f);}
 public static Modifier edgeSpacerWeight(RowScopeInstance scope,Modifier modifier,float oldWeight,boolean oldFill){return SizeKt.u(modifier,0f);}
 public static void render(String ignored,long color,long size,float letterSpacing,float scale,Composer composer,int changed,int defaults){
  if(Wave.app!=null)Palette.capture(composer,Wave.app);
  final int ink=Wave.app==null?0xfff5f5f5:Palette.load(Wave.app).fg;
  Modifier fill=RowScopeInstance.a.a(Modifier.Companion,1f,true);
  AndroidView_androidKt.AndroidView(FACTORY,fill,new Function1<View,Unit>(){public Unit invoke(View view){((LogoView)view).setInk(ink);return Unit.a;}},composer,0,0);
 }
 private static synchronized Bitmap artwork(Context context){if(artwork==null)try(InputStream in=context.getAssets().open("lane_editor/header-logo129.png")){BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=4;options.inPreferredConfig=Bitmap.Config.ARGB_8888;artwork=BitmapFactory.decodeStream(in,null,options);}catch(IOException e){android.util.Log.e("LaneHeader","Logo asset could not be read",e);}return artwork;}
 public static final class LogoView extends View {
  private final Bitmap image;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);private final Rect source;private final RectF destination=new RectF();private final int[] location=new int[2],rootLocation=new int[2];private int ink;
  LogoView(Context context){super(context);image=artwork(context);if(image!=null){float sx=image.getWidth()/1497f,sy=image.getHeight()/1051f;source=new Rect(Math.round(28*sx),Math.round(67*sy),Math.round(1473*sx),Math.round(1022*sy));}else source=new Rect();setContentDescription("Lane");setClickable(false);setFocusable(false);setInk(Palette.load(context).fg);}
  void setInk(int color){if(ink==color)return;ink=color;paint.setColorFilter(new PorterDuffColorFilter(color,PorterDuff.Mode.SRC_IN));invalidate();}
  @Override protected void onMeasure(int widthSpec,int heightSpec){float density=getResources().getDisplayMetrics().density;setMeasuredDimension(resolveSize(Math.round(84*density),widthSpec),resolveSize(Math.round(48*density),heightSpec));}
  @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);if(image==null||source.isEmpty()||getWidth()==0||getHeight()==0)return;float density=getResources().getDisplayMetrics().density;float factor=Math.min((getWidth()-8*density)/source.width(),(getHeight()-4*density)/source.height());if(factor<=0)return;float width=source.width()*factor,height=source.height()*factor;getLocationInWindow(location);View root=getRootView();root.getLocationInWindow(rootLocation);float center=rootLocation[0]+root.getWidth()/2f-location[0];center=Math.max(width/2f,Math.min(getWidth()-width/2f,center));float top=(getHeight()-height)/2f;destination.set(center-width/2f,top,center+width/2f,top+height);canvas.drawBitmap(image,source,destination,paint);}
 }
}
