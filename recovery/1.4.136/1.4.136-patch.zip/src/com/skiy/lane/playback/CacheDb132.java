package com.skiy.lane.playback;
import com.skiy.lane.data.local.db.*;
public final class CacheDb132 {
 public static Object dao(Object source){if(source instanceof DownloadedTracksDao)return source;if(source instanceof LaneDatabase){DownloadedTracksDao result=((LaneDatabase)source).y();if(result!=null)return result;}throw new IllegalArgumentException("Download marker requires LaneDatabase or DownloadedTracksDao");}
}
