import subprocess,shutil
shutil.rmtree('test131-classes',ignore_errors=True)
subprocess.run(['java','-jar','tools/ecj.jar','-nowarn','-1.8','-proc:none','-d','test131-classes','src/com/skiy/lane/wave/SessionStore131.java','tests/com/skiy/lane/wave/Test131.java'],check=True)
subprocess.run(['java','-cp','test131-classes','com.skiy.lane.wave.Test131'],check=True)
