Lane 1.4.136 (336), restored from saved 1.4.131 (331).

This is a newly reconstructed build, not a byte-identical recovery of the lost135.
Preserves all131 application resources, features and platform libraries.
No plugins preinstalled by this update.

Restored132-135 changes:
- DownloadKeeper.mark receives DownloadedTracksDao from LaneDatabase.y().
- Library scanner checks SQLite schema/required fields before catalog queries.
- Both downloaded-ID lookups verify SQLite headers/table/column before querying.
- Player metadata lookup verifies index < media item count, preserving negative guard.
- Separate bounded important-event journals survive codec DEBUG flooding.
- Current queue snapshot is at report beginning and includes producer stage,
  WorkManager retention, foreground/network, work UUID, enqueued/restored/failure.
- Optional playlist-wide stream prefetch gets an existing Kotlin withTimeout(5000)
  boundary. Existing per-track URL resolution remains the fallback. Cancellation
  context and original coroutine continuation/finally paths are preserved.
- Preparation and WorkManager submission/acceptance events are logged.
Additional136 defenses: null-context registry returns an empty set; catalog
also checks SQLite magic before opening unrelated files.

Validation completed:
-135 host journal regression cases.
-50000-line codec flood, important event retention across process rotation.
-118 SQLite header cases; DAO/direct database receiver tests.
-SQLite empty/unrelated/missing-column/valid schema fixtures.
-8008 index boundary cases, actual DEX guard inspected.
-100 continuation forwarding contract fixtures (host doubles, not Android execution).
-53662 original classes compared. Only six listed methods and owned helper
 classes changed; seven new helper classes;603helper references resolved.
-All14027application method references resolved; no compile-only SDK classes leaked.
-APK ZIP/DEX checksums, method limits, native16KiB alignment and V2/V3 signature
 verified. Same update signing certificate as131.

No emulator/phone available. Actual installation, Android coroutine timing,
network downloads and playback on device have not been verified. User's exact
waiting/0% failure reason is still not proven; timeout removes one pre-worker stall.

Rebuild kit contains saved base131APK, neutral SDK source stubs, helper sources,
precompiled ManifestEditor bootstrap, tool jars and build scripts/tests.
Actual provider credentials and editor signing keys remain in the base APK only;
they are not supplied separately. Do not package sdk/ classes into APK.
Requires Java17 and Python3. Run python3 build136.py from this folder.
python3 test131.py and python3 verify136.py run primary verification.
Compile Verify136.java/Verify126.java/Build126.java/AppLinks88.java with ECJ first
if their .class files are absent; or run python3 verify_all.py.
